/* ================================================================
   AUTOSCRAPE — Shared mock data + helpers (replace with API calls)
   ================================================================ */
const MAKES  = ['Toyota','Ford','Honda','Chevrolet','BMW','Hyundai','Tesla','Nissan','Jeep','Audi','Mazda','Subaru','Kia','Volkswagen','Ram'];
const MODELS = {Toyota:['Camry','Corolla','RAV4','Highlander','Tacoma','4Runner'],Ford:['F-150','Escape','Explorer','Mustang','Edge','Bronco'],Honda:['Accord','Civic','CR-V','Pilot','HR-V','Passport'],Chevrolet:['Silverado','Equinox','Tahoe','Malibu','Colorado','Traverse'],BMW:['3 Series','5 Series','X3','X5','M3','M5'],Hyundai:['Tucson','Santa Fe','Sonata','Elantra','Palisade','Venue'],Tesla:['Model 3','Model Y','Model S','Model X'],Nissan:['Altima','Rogue','Frontier','Maxima','Pathfinder','Murano'],Jeep:['Grand Cherokee','Wrangler','Cherokee','Compass','Gladiator'],Audi:['A4','A6','Q5','Q7','A3','e-tron'],Mazda:['CX-5','Mazda3','CX-9','CX-30','MX-5'],Subaru:['Outback','Forester','Crosstrek','Impreza','Legacy'],Kia:['Sorento','Telluride','Sportage','K5','Soul'],Volkswagen:['Tiguan','Jetta','Atlas','Golf','Passat'],Ram:['1500','2500','ProMaster']};
const TRIMS  = ['SE','LE','XLE','Limited','Sport','EX','Touring','Premium','Base','Platinum','S','SL','SR5'];
const ZIPS   = ['75201','75034','75093','75035','76051','78201','75069','75074','75287','75254'];
const COLORS = ['White','Black','Silver','Gray','Red','Blue','Green','Brown','Gold','Navy'];
const DEALERS = [
  {name:'Park Place Dealerships',phone:'(972) 241-0900',addr:'6113 Lemmon Ave',city:'Dallas',state:'TX',zip:'75209',website:'parkplace.com',listings:34},
  {name:'Huffines Auto Dealerships',phone:'(972) 543-2000',addr:'701 N Central Expy',city:'Plano',state:'TX',zip:'75074',website:'huffines.com',listings:28},
  {name:'AutoNation Toyota Frisco',phone:'(469) 312-5800',addr:'9700 John W Elliott Dr',city:'Frisco',state:'TX',zip:'75033',website:'autonation.com',listings:41},
  {name:'Classic Chevrolet Grapevine',phone:'(817) 329-6111',addr:'1 Classic Dr',city:'Grapevine',state:'TX',zip:'76051',website:'classicchevrolet.com',listings:22},
  {name:'Bob Tomes Ford McKinney',phone:'(972) 563-4600',addr:'1400 W Virginia St',city:'McKinney',state:'TX',zip:'75069',website:'bobtomes.com',listings:37},
  {name:'Sewell Automotive Companies',phone:'(214) 526-1000',addr:'4035 Lemmon Ave',city:'Dallas',state:'TX',zip:'75219',website:'sewell.com',listings:19},
  {name:'Southwest Kia Rockwall',phone:'(972) 722-9000',addr:'1707 Sunset Blvd',city:'Rockwall',state:'TX',zip:'75087',website:'southwestkia.com',listings:15},
  {name:'Texas Motor Cars',phone:'(214) 350-2600',addr:'7200 Harry Hines Blvd',city:'Dallas',state:'TX',zip:'75235',website:'texasmotorcars.com',listings:11},
  {name:'Freeman Auto Group',phone:'(972) 276-7000',addr:'2100 E I-30',city:'Garland',state:'TX',zip:'75043',website:'freemanautomotivegroup.com',listings:29},
  {name:'Toyota of Plano',phone:'(972) 422-7900',addr:'3400 US-75',city:'Plano',state:'TX',zip:'75074',website:'toyotaofplano.com',listings:48},
];

function r(arr) { return arr[Math.floor(Math.random()*arr.length)]; }
function ri(a,b) { return Math.floor(Math.random()*(b-a+1))+a; }
function genVIN() { return 'ABCDEFGHJKLMNPRSTUVWXYZ0123456789'.split('').sort(()=>Math.random()-0.5).join('').slice(0,17); }
function fmtPrice(n) { return n ? '$'+n.toLocaleString() : '—'; }
function fmtMiles(n) { return n ? n.toLocaleString()+' mi' : '—'; }
function fmtDate(iso) {
  if(!iso) return '—';
  return new Date(iso).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'});
}

function genListings(n) {
  return Array.from({length:n},(_,i)=>{
    const make = r(MAKES);
    const model = r(MODELS[make]||['Unknown']);
    const year = ri(2018,2024);
    const dealer = r(DEALERS);
    const src = Math.random()>0.5?'cars_com':'cargurus';
    const vin = genVIN();
    return {
      id:`lst-${i+1}`,
      source: src,
      zip_code: r(ZIPS),
      listing_url: `https://${src==='cars_com'?'cars.com':'cargurus.com'}/listing/${vin}`,
      title: `${year} ${make} ${model}`,
      year, make, model,
      trim: r(TRIMS),
      color: r(COLORS),
      vin,
      price: ri(11000,78000),
      mileage: ri(800,105000),
      condition: Math.random()>0.15?'used':'new',
      search_radius_miles: 50,
      dealer_name: dealer.name,
      dealer_phone: dealer.phone,
      dealer_address: dealer.addr,
      dealer_city: dealer.city,
      dealer_state: dealer.state,
      dealer_zip: dealer.zip,
      dealer_website: dealer.website,
      first_seen_at: new Date(Date.now()-ri(0,21)*24*3600000).toISOString(),
    };
  });
}

function genJobs(n) {
  const statuses = ['done','done','done','done','running','failed','partial'];
  const adapters = [['cars_com'],['cargurus'],['cars_com','cargurus']];
  return Array.from({length:n},(_,i)=>{
    const status = r(statuses);
    const zipCount = ri(1,5);
    const created = new Date(Date.now()-ri(0,30)*24*3600000);
    const found = status==='running'? ri(0,100) : ri(50,500);
    return {
      id: `job-${String(i+1).padStart(4,'0')}`,
      uuid: genVIN().slice(0,8).toLowerCase()+'-'+genVIN().slice(0,4).toLowerCase(),
      status,
      zip_codes: Array.from({length:zipCount},()=>r(ZIPS)),
      adapters: r(adapters),
      radius_miles: r([25,50,75,100]),
      total_found: found,
      total_new: Math.floor(found*ri(40,90)/100),
      created_at: created.toISOString(),
      started_at: new Date(created.getTime()+ri(1,30)*1000).toISOString(),
      finished_at: status==='running'?null:new Date(created.getTime()+ri(30,600)*1000).toISOString(),
      error_message: status==='failed'?'Adapter timeout: cargurus returned 429 after 3 retries':null,
    };
  });
}

window.MOCK = { listings: genListings(312), jobs: genJobs(48), dealers: DEALERS };
